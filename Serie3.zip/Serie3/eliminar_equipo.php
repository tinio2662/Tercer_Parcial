<?php
require "conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = (int) $_POST["id"];
    $consulta = $conexion->prepare("DELETE FROM equipos WHERE id = ?");

    try {
        $consulta->execute(array($id));
        header("Location: index.php");
        exit;
    } catch (PDOException $error) {
        die("No se puede eliminar el equipo porque tiene reservas registradas.");
    }
}

header("Location: index.php");
exit;
?>
