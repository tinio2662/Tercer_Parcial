<?php
require "conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = (int) $_POST["id"];
    $consulta = $conexion->prepare("DELETE FROM reservas WHERE id = ?");
    $consulta->execute(array($id));
}

header("Location: reservas.php");
exit;
?>
