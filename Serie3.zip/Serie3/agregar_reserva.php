<?php
header("Location: reservas.php");
exit;
?>
