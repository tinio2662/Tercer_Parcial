<?php
require "conexion.php";

$tipos = array("Laptop", "Proyector", "Tablet", "Camara", "Laboratorio");
$estados = array("Disponible", "Mantenimiento");
$id = isset($_GET["id"]) ? (int) $_GET["id"] : 0;
$consulta = $conexion->prepare("SELECT * FROM equipos WHERE id = ?");
$consulta->execute(array($id));
$equipo = $consulta->fetch(PDO::FETCH_ASSOC);

if (!$equipo) {
    die("El equipo no existe.");
}

$tipo_seleccionado_actual = in_array($equipo["tipo"], $tipos, true) ? $equipo["tipo"] : "otro";
$tipo_personalizado_actual = $tipo_seleccionado_actual == "otro" ? $equipo["tipo"] : "";
$mensaje = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo = trim($_POST["codigo"]);
    $nombre = trim($_POST["nombre"]);
    $tipo_seleccionado = $_POST["tipo_seleccionado"];
    if ($tipo_seleccionado == "otro") {
        $tipo = trim($_POST["tipo_personalizado"]);
    } else {
        $tipo = $tipo_seleccionado;
    }
    $descripcion = trim($_POST["descripcion"]);
    $ubicacion = trim($_POST["ubicacion"]);
    $estado = $_POST["estado"];

    if ($codigo == "" || $nombre == "" || $tipo == "" || $ubicacion == "") {
        $mensaje = "Complete los campos obligatorios.";
    } elseif (
        ($tipo_seleccionado != "otro" && !in_array($tipo_seleccionado, $tipos, true)) ||
        strlen($tipo) > 50 || !in_array($estado, $estados, true)
    ) {
        $mensaje = "El tipo no puede superar 50 caracteres y debe seleccionar un estado valido.";
    } else {
        try {
            $sql = "UPDATE equipos SET codigo = ?, nombre = ?, tipo = ?, descripcion = ?,
                    ubicacion = ?, estado = ? WHERE id = ?";
            $consulta = $conexion->prepare($sql);
            $consulta->execute(array(
                $codigo, $nombre, $tipo, $descripcion == "" ? null : $descripcion,
                $ubicacion, $estado, $id
            ));
            header("Location: index.php");
            exit;
        } catch (PDOException $error) {
            $mensaje = "No se pudo actualizar. Revise que el codigo no este repetido.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar equipo</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h1>Editar equipo</h1>
    <nav><a href="index.php">Volver a equipos</a></nav>
    <?php if ($mensaje != "") { ?><p><?php echo htmlspecialchars($mensaje); ?></p><?php } ?>

    <form method="post">
        <label>Codigo:
            <input type="text" name="codigo" maxlength="20" value="<?php echo htmlspecialchars($equipo["codigo"]); ?>" required>
        </label>
        <label>Nombre:
            <input type="text" name="nombre" maxlength="100" value="<?php echo htmlspecialchars($equipo["nombre"]); ?>" required>
        </label>
        <label>Tipo:
            <select name="tipo_seleccionado" id="tipo_seleccionado" required>
                <?php foreach ($tipos as $tipo) { ?>
                    <option value="<?php echo htmlspecialchars($tipo); ?>" <?php if ($tipo_seleccionado_actual == $tipo) { echo "selected"; } ?>>
                        <?php echo htmlspecialchars($tipo); ?>
                    </option>
                <?php } ?>
                <option value="otro" <?php if ($tipo_seleccionado_actual == "otro") { echo "selected"; } ?>>Agregar otro tipo...</option>
            </select>
            <input type="text" name="tipo_personalizado" id="tipo_personalizado" maxlength="50"
                placeholder="Escriba el tipo de equipo"
                value="<?php echo htmlspecialchars($tipo_personalizado_actual); ?>"
                <?php if ($tipo_seleccionado_actual != "otro") { echo "hidden"; } ?>
                <?php if ($tipo_seleccionado_actual == "otro") { echo "required"; } ?>>
        </label>
        <label>Descripcion:
            <textarea name="descripcion" maxlength="255"><?php echo htmlspecialchars($equipo["descripcion"] ?? ""); ?></textarea>
        </label>
        <label>Ubicacion:
            <input type="text" name="ubicacion" maxlength="100" value="<?php echo htmlspecialchars($equipo["ubicacion"]); ?>" required>
        </label>
        <label>Estado:
            <select name="estado">
                <?php foreach ($estados as $estado) { ?>
                    <option value="<?php echo htmlspecialchars($estado); ?>" <?php if ($equipo["estado"] == $estado) { echo "selected"; } ?>>
                        <?php echo htmlspecialchars($estado); ?>
                    </option>
                <?php } ?>
            </select>
        </label>
        <button type="submit">Guardar cambios</button>
    </form>
    <script>
        var tipoSeleccionado = document.getElementById("tipo_seleccionado");
        var tipoPersonalizado = document.getElementById("tipo_personalizado");

        tipoSeleccionado.addEventListener("change", function () {
            tipoPersonalizado.hidden = tipoSeleccionado.value != "otro";
            tipoPersonalizado.required = tipoSeleccionado.value == "otro";
        });
    </script>
</body>
</html>
