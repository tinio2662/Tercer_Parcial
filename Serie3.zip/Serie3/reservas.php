<?php
require "conexion.php";

$mensaje = "";
$equipos_seleccionados = array();

if (isset($_SERVER["REQUEST_METHOD"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["equipo_ids"]) && is_array($_POST["equipo_ids"])) {
        foreach ($_POST["equipo_ids"] as $equipo_id) {
            $equipo_id = (int) $equipo_id;
            if ($equipo_id > 0 && !in_array($equipo_id, $equipos_seleccionados, true)) {
                $equipos_seleccionados[] = $equipo_id;
            }
        }
    }

    $nombre = trim($_POST["nombre"]);
    $carne = trim($_POST["carne"]);
    $fecha = $_POST["fecha"];
    $hora_inicio = $_POST["hora_inicio"];
    $hora_fin = $_POST["hora_fin"];
    $motivo = trim($_POST["motivo"]);

    if (count($equipos_seleccionados) == 0 || $nombre == "" || $carne == "" || $fecha == "" ||
        $hora_inicio == "" || $hora_fin == "" || $hora_fin <= $hora_inicio) {
        $mensaje = "Seleccione al menos un equipo, complete los campos y revise el horario.";
    } else {
        $conexion->beginTransaction();
        $consulta_equipo = $conexion->prepare("SELECT estado FROM equipos WHERE id = ?");
        $consulta_reserva = $conexion->prepare(
            "SELECT COUNT(*) FROM reservas
             WHERE equipo_id = ? AND fecha = ?
             AND hora_inicio < ? AND hora_fin > ?"
        );

        foreach ($equipos_seleccionados as $equipo_id) {
            $consulta_equipo->execute(array($equipo_id));
            $equipo = $consulta_equipo->fetch(PDO::FETCH_ASSOC);

            if (!$equipo || $equipo["estado"] != "Disponible") {
                $mensaje = "Uno de los equipos seleccionados ya no esta disponible.";
                break;
            }

            $consulta_reserva->execute(array($equipo_id, $fecha, $hora_fin, $hora_inicio));
            if ($consulta_reserva->fetchColumn() > 0) {
                $mensaje = "Uno de los equipos seleccionados ya tiene una reserva en ese horario.";
                break;
            }
        }

        if ($mensaje != "") {
            $conexion->rollBack();
        } else {
            $sql = "INSERT INTO reservas
                    (equipo_id, nombre, carne, fecha, hora_inicio, hora_fin, motivo)
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $consulta = $conexion->prepare($sql);

            foreach ($equipos_seleccionados as $equipo_id) {
                $consulta->execute(array(
                    $equipo_id, $nombre, $carne, $fecha, $hora_inicio, $hora_fin,
                    $motivo == "" ? null : $motivo
                ));
            }

            $conexion->commit();
            header("Location: reservas.php");
            exit;
        }
    }
}

$consulta = $conexion->query("SELECT id, codigo, nombre FROM equipos WHERE estado = 'Disponible' ORDER BY nombre");
$equipos = $consulta->fetchAll(PDO::FETCH_ASSOC);

$sql = "SELECT reservas.*, equipos.codigo, equipos.nombre AS equipo
        FROM reservas
        INNER JOIN equipos ON reservas.equipo_id = equipos.id
        ORDER BY reservas.fecha DESC, reservas.hora_inicio DESC";
$reservas = $conexion->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservas</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h1>Reservas de equipos</h1>
    <nav>
        <a href="index.php">Equipos</a>
        <a href="reservas.php">Reservas</a>
    </nav>
    <h2>Registrar reserva</h2>
    <?php if ($mensaje != "") { ?><p><?php echo htmlspecialchars($mensaje); ?></p><?php } ?>
    <?php if (count($equipos) == 0) { ?>
        <p>No hay equipos disponibles para reservar.</p>
    <?php } else { ?>
        <form method="post" action="reservas.php">
            <label>Buscar equipos:
                <input type="search" id="buscar_equipo" placeholder="Escriba el codigo o nombre">
            </label>
            <p id="contador_equipos">0 equipos seleccionados</p>
            <div class="lista-equipos" id="lista_equipos">
                <?php foreach ($equipos as $equipo) { ?>
                    <label class="equipo-opcion">
                        <input type="checkbox" name="equipo_ids[]" value="<?php echo $equipo["id"]; ?>"
                            <?php if (in_array((int) $equipo["id"], $equipos_seleccionados, true)) { echo "checked"; } ?>>
                        <?php echo htmlspecialchars($equipo["codigo"] . " - " . $equipo["nombre"]); ?>
                    </label>
                <?php } ?>
            </div>
            <label>Nombre del estudiante:
                <input type="text" name="nombre" maxlength="100" required>
            </label>
            <label>Carne:
                <input type="text" name="carne" maxlength="20" required>
            </label>
            <label>Fecha:
                <input type="date" name="fecha" required>
            </label>
            <label>Hora de inicio:
                <input type="time" name="hora_inicio" required>
            </label>
            <label>Hora final:
                <input type="time" name="hora_fin" required>
            </label>
            <label>Motivo:
                <textarea name="motivo" maxlength="255"></textarea>
            </label>
            <button type="submit">Guardar reservas</button>
        </form>
    <?php } ?>

    <h2>Reservas registradas</h2>
    <?php if (count($reservas) > 0) { ?>
        <table>
            <thead>
                <tr>
                    <th>Equipo</th>
                    <th>Estudiante</th>
                    <th>Carne</th>
                    <th>Fecha</th>
                    <th>Hora inicio</th>
                    <th>Hora fin</th>
                    <th>Motivo</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reservas as $reserva) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($reserva["codigo"] . " - " . $reserva["equipo"]); ?></td>
                        <td><?php echo htmlspecialchars($reserva["nombre"]); ?></td>
                        <td><?php echo htmlspecialchars($reserva["carne"]); ?></td>
                        <td><?php echo htmlspecialchars($reserva["fecha"]); ?></td>
                        <td><?php echo htmlspecialchars($reserva["hora_inicio"]); ?></td>
                        <td><?php echo htmlspecialchars($reserva["hora_fin"]); ?></td>
                        <td><?php echo htmlspecialchars($reserva["motivo"] ?? ""); ?></td>
                        <td>
                            <form action="eliminar_reserva.php" method="post" class="formulario-corto">
                                <input type="hidden" name="id" value="<?php echo $reserva["id"]; ?>">
                                <button type="submit">Cancelar</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php } else { ?>
        <p>No hay reservas registradas.</p>
    <?php } ?>
    <script>
        var buscarEquipo = document.getElementById("buscar_equipo");
        var listaEquipos = document.getElementById("lista_equipos");
        var contadorEquipos = document.getElementById("contador_equipos");

        function actualizarEquipos() {
            var opciones = listaEquipos.querySelectorAll(".equipo-opcion");
            var seleccionados = 0;
            var busqueda = buscarEquipo.value.toLowerCase();

            opciones.forEach(function (opcion) {
                var coincide = opcion.textContent.toLowerCase().includes(busqueda);
                opcion.hidden = !coincide;

                if (opcion.querySelector("input").checked) {
                    seleccionados++;
                }
            });

            contadorEquipos.textContent = seleccionados + " equipos seleccionados";
        }

        buscarEquipo.addEventListener("input", actualizarEquipos);
        listaEquipos.addEventListener("change", actualizarEquipos);
        actualizarEquipos();
    </script>
</body>
</html>
