<?php
$servidor = "localhost";
$usuario = "root";
$clave = "";
$base_datos = "serie3_equipos";

try {
    $conexion = new PDO(
        "mysql:host=$servidor;dbname=$base_datos;charset=utf8mb4",
        $usuario,
        $clave
    );
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $error) {
    die("No se pudo conectar con la base de datos. Importe primero el archivo database.sql. " . $error->getMessage());
}
?>
