<?php
require "conexion.php";

$tipos = array("Laptop", "Proyector", "Tablet", "Camara", "Laboratorio");
$estados = array("Disponible", "Mantenimiento");
$mensaje = "";

if (isset($_SERVER["REQUEST_METHOD"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo = trim($_POST["codigo"]);
    $nombre = trim($_POST["nombre"]);
    $tipo_seleccionado = $_POST["tipo_seleccionado"];
    if ($tipo_seleccionado == "otro") {
        $tipo = trim($_POST["tipo_personalizado"]);
    } else {
        $tipo = $tipo_seleccionado;
    }
    $descripcion = trim($_POST["descripcion"]);
    $ubicacion = trim($_POST["ubicacion"]);
    $estado = $_POST["estado"];

    if ($codigo == "" || $nombre == "" || $tipo == "" || $ubicacion == "") {
        $mensaje = "Complete los campos obligatorios.";
    } elseif (
        ($tipo_seleccionado != "otro" && !in_array($tipo_seleccionado, $tipos, true)) ||
        strlen($tipo) > 50 || !in_array($estado, $estados, true)
    ) {
        $mensaje = "El tipo no puede superar 50 caracteres y debe seleccionar un estado valido.";
    } else {
        try {
            $sql = "INSERT INTO equipos (codigo, nombre, tipo, descripcion, ubicacion, estado)
                    VALUES (?, ?, ?, ?, ?, ?)";
            $consulta = $conexion->prepare($sql);
            $consulta->execute(array(
                $codigo, $nombre, $tipo, $descripcion == "" ? null : $descripcion,
                $ubicacion, $estado
            ));
            header("Location: index.php");
            exit;
        } catch (PDOException $error) {
            $mensaje = "No se pudo guardar el equipo. Revise que el codigo no este repetido.";
        }
    }
}

$consulta = $conexion->query("SELECT * FROM equipos ORDER BY id DESC");
$equipos = $consulta->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de equipos</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <header class="cabecera-modulo">
        <h1>Control de equipos</h1>
        <nav>
            <a href="index.php">Equipos</a>
            <a href="reservas.php">Reservas</a>
        </nav>
        <h2>Listado de equipos</h2>
    </header>
    <h3>Registrar equipo</h3>
    <?php if ($mensaje != "") { ?><p><?php echo htmlspecialchars($mensaje); ?></p><?php } ?>
    <form method="post" action="index.php">
        <label>Codigo:
            <input type="text" name="codigo" maxlength="20" required>
        </label>
        <label>Nombre:
            <input type="text" name="nombre" maxlength="100" required>
        </label>
        <label>Tipo:
            <select name="tipo_seleccionado" id="tipo_seleccionado" required>
                <?php foreach ($tipos as $tipo) { ?>
                    <option value="<?php echo htmlspecialchars($tipo); ?>"><?php echo htmlspecialchars($tipo); ?></option>
                <?php } ?>
                <option value="otro">Agregar otro tipo...</option>
            </select>
            <input type="text" name="tipo_personalizado" id="tipo_personalizado" maxlength="50" placeholder="Escriba el tipo de equipo" hidden>
        </label>
        <label>Descripcion:
            <textarea name="descripcion" maxlength="255"></textarea>
        </label>
        <label>Ubicacion:
            <input type="text" name="ubicacion" maxlength="100" required>
        </label>
        <label>Estado:
            <select name="estado">
                <?php foreach ($estados as $estado) { ?>
                    <option value="<?php echo htmlspecialchars($estado); ?>"><?php echo htmlspecialchars($estado); ?></option>
                <?php } ?>
            </select>
        </label>
        <button type="submit">Guardar equipo</button>
    </form>

    <h3>Equipos registrados</h3>
    <?php if (count($equipos) > 0) { ?>
        <table>
            <thead>
                <tr>
                    <th>Codigo</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Ubicacion</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($equipos as $equipo) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($equipo["codigo"]); ?></td>
                        <td><?php echo htmlspecialchars($equipo["nombre"]); ?></td>
                        <td><?php echo htmlspecialchars($equipo["tipo"]); ?></td>
                        <td><?php echo htmlspecialchars($equipo["ubicacion"]); ?></td>
                        <td><?php echo htmlspecialchars($equipo["estado"]); ?></td>
                        <td>
                            <a href="editar_equipo.php?id=<?php echo $equipo["id"]; ?>">Editar</a>
                            <form action="eliminar_equipo.php" method="post" class="formulario-corto">
                                <input type="hidden" name="id" value="<?php echo $equipo["id"]; ?>">
                                <button type="submit">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php } else { ?>
        <p>No hay equipos registrados.</p>
    <?php } ?>
    <script>
        var tipoSeleccionado = document.getElementById("tipo_seleccionado");
        var tipoPersonalizado = document.getElementById("tipo_personalizado");

        tipoSeleccionado.addEventListener("change", function () {
            tipoPersonalizado.hidden = tipoSeleccionado.value != "otro";
            tipoPersonalizado.required = tipoSeleccionado.value == "otro";
        });
    </script>
</body>
</html>
