<?php
$servidor = "127.0.0.1";
$puerto = "3306";
$baseDatos = "panaderia";
$usuario = "root";
$contrasena = "";
$charset = "utf8";

$dsn = "mysql:host=$servidor;port=$puerto;dbname=$baseDatos;charset=$charset";
$conexion = new PDO($dsn, $usuario, $contrasena);
$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>
