<?php
session_start();
require_once "conexion.php";

if (empty($_SESSION["token"])) {
    $_SESSION["token"] = bin2hex(random_bytes(32));
}

function escapar($valor)
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, "UTF-8");
}

$error = "";
$datosFormulario = [
    "nombre" => "",
    "descripcion" => "",
    "precio" => "",
];
$idEditar = null;
$mensaje = "";

if (isset($_GET["ok"])) {
    $mensajes = [
        "creado" => "El producto fue agregado.",
        "editado" => "El producto fue actualizado.",
        "eliminado" => "El producto fue eliminado.",
    ];
    $mensaje = $mensajes[$_GET["ok"]] ?? "";
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $token = $_POST["token"] ?? "";
    $accion = $_POST["accion"] ?? "";

    if (!hash_equals($_SESSION["token"], $token)) {
        $error = "La solicitud no es valida. Recarga la pagina e intentalo otra vez.";
    } elseif ($accion === "eliminar") {
        $id = filter_var($_POST["id"] ?? "", FILTER_VALIDATE_INT);

        if ($id === false || $id < 1) {
            $error = "El producto seleccionado no es valido.";
        } else {
            $consulta = $conexion->prepare("DELETE FROM productos WHERE id = ?");
            $consulta->execute([$id]);

            if ($consulta->rowCount() === 0) {
                $error = "No se encontro el producto que quieres eliminar.";
            } else {
                $mensaje = "El producto fue eliminado.";
                $idEditar = null;
                $datosFormulario = [
                    "nombre" => "",
                    "descripcion" => "",
                    "precio" => "",
                ];
            }
        }
    } elseif ($accion === "crear" || $accion === "editar") {
        $datosFormulario["nombre"] = trim($_POST["nombre"] ?? "");
        $datosFormulario["descripcion"] = trim($_POST["descripcion"] ?? "");
        $datosFormulario["precio"] = trim($_POST["precio"] ?? "");

        if ($accion === "editar") {
            $idEditar = filter_var($_POST["id"] ?? "", FILTER_VALIDATE_INT);
            if ($idEditar === false || $idEditar < 1) {
                $error = "El producto seleccionado no es valido.";
            }
        }

        if ($error === "" && $datosFormulario["nombre"] === "") {
            $error = "Escribe el nombre del producto.";
        } elseif ($error === "" && strlen($datosFormulario["nombre"]) > 100) {
            $error = "El nombre no puede tener mas de 100 caracteres.";
        } elseif ($error === "" && $datosFormulario["descripcion"] === "") {
            $error = "Escribe la descripcion del producto.";
        } elseif ($error === "" && strlen($datosFormulario["descripcion"]) > 255) {
            $error = "La descripcion no puede tener mas de 255 caracteres.";
        } elseif ($error === "" && !preg_match('/^\d+(\.\d{1,2})?$/', $datosFormulario["precio"])) {
            $error = "Escribe un precio valido, por ejemplo 5 o 5.50.";
        } elseif ($error === "" && (float) $datosFormulario["precio"] > 999999.99) {
            $error = "El precio es demasiado alto.";
        }

        if ($error === "") {
            if ($accion === "crear") {
                $consulta = $conexion->prepare(
                    "INSERT INTO productos (nombre, descripcion, precio) VALUES (?, ?, ?)"
                );
                $consulta->execute([
                    $datosFormulario["nombre"],
                    $datosFormulario["descripcion"],
                    $datosFormulario["precio"],
                ]);
                $mensaje = "El producto fue agregado.";
                $idEditar = null;
                $datosFormulario = [
                    "nombre" => "",
                    "descripcion" => "",
                    "precio" => "",
                ];
            } else {
                $consulta = $conexion->prepare(
                    "UPDATE productos SET nombre = ?, descripcion = ?, precio = ? WHERE id = ?"
                );
                $consulta->execute([
                    $datosFormulario["nombre"],
                    $datosFormulario["descripcion"],
                    $datosFormulario["precio"],
                    $idEditar,
                ]);
                $mensaje = "El producto fue actualizado.";
                $idEditar = null;
                $datosFormulario = [
                    "nombre" => "",
                    "descripcion" => "",
                    "precio" => "",
                ];
            }
        }
    } else {
        $error = "La accion solicitada no es valida.";
    }
}

if ($_SERVER["REQUEST_METHOD"] !== "POST" && isset($_GET["editar"])) {
    $idEditar = filter_var($_GET["editar"], FILTER_VALIDATE_INT);

    if ($idEditar === false || $idEditar < 1) {
        $error = "El producto seleccionado no es valido.";
        $idEditar = null;
    } else {
        $consulta = $conexion->prepare(
            "SELECT nombre, descripcion, precio FROM productos WHERE id = ?"
        );
        $consulta->execute([$idEditar]);
        $productoEditar = $consulta->fetch(PDO::FETCH_ASSOC);

        if ($productoEditar === false) {
            $error = "No se encontro el producto que quieres editar.";
            $idEditar = null;
        } else {
            $datosFormulario = $productoEditar;
        }
    }
}

$productos = $conexion->query(
    "SELECT id, nombre, descripcion, precio FROM productos ORDER BY id"
)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panaderia Especial</title>
    <link rel="stylesheet" href="estilos.css?v=2">
</head>
<body>
    <header>
        <h1>Panaderia Especial</h1>
    </header>

    <main>
        <section id="productos">
            <h2>Nuestros productos</h2>

            <?php if ($mensaje !== "") { ?>
                <p class="mensaje"><?php echo escapar($mensaje); ?></p>
            <?php } ?>
            <?php if ($error !== "") { ?>
                <p class="error"><?php echo escapar($error); ?></p>
            <?php } ?>

            <?php if (count($productos) === 0) { ?>
                <p>No hay productos registrados todavia.</p>
            <?php } else { ?>
                <div class="productos">
                    <?php foreach ($productos as $producto) { ?>
                        <article class="producto">
                            <h3><?php echo escapar($producto["nombre"]); ?></h3>
                            <p><?php echo escapar($producto["descripcion"]); ?></p>
                            <p>Precio: Q<?php echo number_format((float) $producto["precio"], 2); ?></p>
                            <a href="index.php?editar=<?php echo (int) $producto["id"]; ?>">Editar</a>
                            <form method="post" class="form-eliminar"
                                  onsubmit="return confirm('Quieres eliminar este producto?');">
                                <input type="hidden" name="token" value="<?php echo escapar($_SESSION["token"]); ?>">
                                <input type="hidden" name="accion" value="eliminar">
                                <input type="hidden" name="id" value="<?php echo (int) $producto["id"]; ?>">
                                <button type="submit">Eliminar</button>
                            </form>
                        </article>
                    <?php } ?>
                </div>
            <?php } ?>
        </section>

        <section id="formulario">
            <h2><?php echo $idEditar === null ? "Agregar producto" : "Editar producto"; ?></h2>
            <form method="post">
                <input type="hidden" name="token" value="<?php echo escapar($_SESSION["token"]); ?>">
                <input type="hidden" name="accion" value="<?php echo $idEditar === null ? "crear" : "editar"; ?>">
                <?php if ($idEditar !== null) { ?>
                    <input type="hidden" name="id" value="<?php echo (int) $idEditar; ?>">
                <?php } ?>

                <label for="nombre">Nombre</label>
                <input type="text" id="nombre" name="nombre" maxlength="100" required
                       value="<?php echo escapar($datosFormulario["nombre"]); ?>">

                <label for="descripcion">Descripcion</label>
                <textarea id="descripcion" name="descripcion" maxlength="255" required><?php
                    echo escapar($datosFormulario["descripcion"]);
                ?></textarea>

                <label for="precio">Precio (Q)</label>
                <input type="number" id="precio" name="precio" min="0" max="999999.99"
                       step="0.01" required value="<?php echo escapar($datosFormulario["precio"]); ?>">

                <button type="submit"><?php echo $idEditar === null ? "Agregar" : "Guardar cambios"; ?></button>
                <?php if ($idEditar !== null) { ?>
                    <a href="index.php">Cancelar</a>
                <?php } ?>
            </form>
        </section>
    </main>
</body>
</html>
